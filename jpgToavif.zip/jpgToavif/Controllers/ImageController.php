<?php

namespace App\Http\Controllers;

use App\Helpers\Optimize;
use App\Helpers\Helper;
use Illuminate\Support\Facades\Log;

class ImageController extends Controller
{
    public function index()
    {
        echo 'TS static files.';
    }

    public function show($path)
    {

        $info = Helper::parse($path);
        if (Helper::exist($info)) {
            Log::info('file exist', $info);
            return Helper::response($path);
        }

        if (!Helper::exist([...$info, 'ext' => 'jpg', 'w' => false])) {
            return response('', 404);
        }

        if ($info['w']) {
            if (!in_array($info['w'], Helper::SIZES)) {
                return response('', 404);
            }
            if (!Helper::exist([...$info, 'ext' => 'jpg'])) {
                Helper::resizeJpg([...$info, 'ext' => 'jpg']);
            }
        }

        if ($info['ext'] == 'webp' && !Helper::exist($info)) {
            Helper::toWebp($info);
        }

        if ($info['ext'] == 'avif' && !Helper::exist($info)) {
            Helper::toAvif($info);
        }

        return Helper::response($info);
    }
}
