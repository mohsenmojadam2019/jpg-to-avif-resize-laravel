<?php

namespace App\Http\Controllers\Api;

use App\Helpers\Helper;
use App\Helpers\SizeReducer;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;

class ImageController extends Controller
{
    public function store(Request $request, $type = 'file')
    {
        if (!$request->hasFile('image')) {
            $response = [
                'status' => false,
                'message' => 'File is not exists!'
            ];
            return response()->json($response);
        }

        $image = $request->file('image');

        $path = '/' . ($type == 'product' ? 'p/' : '') . date('Y/m/d') . '/';
        $original_name = basename($image->getClientOriginalName(), '.' . $image->getClientOriginalExtension());
        if(preg_match('/_w\d{2,4}$/', $original_name)){
            $original_name = preg_replace('/_w\d{2,4}$/', '', $original_name);
        }
        $ext = strtolower($image->getClientOriginalExtension());
        $ext = str_replace('jpeg', 'jpg', $ext);
        $ext = str_replace('png', 'jpg', $ext);
        $name = $original_name . '.' . $ext;
        $n = 1;

        while (file_exists(public_path($path . $name))) {
            $name = $original_name . '-' . $n . '.' . $ext;
            $n++;
        }

        $image->move(public_path($path), $name);

        SizeReducer::optimize(public_path($path . $name),public_path($path . $name));
        $response = [
            'status' => true,
            'path' => $path . $name,
        ];
        return response()->json($response);
    }

    protected function deleteFile($path)
    {
        $file = public_path($path);
        if (file_exists($file)) {
            File::delete($file);
        }
    }

    public function destroy($path)
    {
        $pathinfo = pathinfo($path);
        foreach (Helper::FORMATS as $format) {
            $this->deleteFile($pathinfo['dirname'] . '/' . $pathinfo['filename'] . '.' . $format);
            foreach (Helper::SIZES as $size) {
                $this->deleteFile($pathinfo['dirname'] . '/' . $pathinfo['filename'] . '_' . $size . '.' . $format);
            }
        }

        $response = [
            'status' => 'true',
            'message' => ''
        ];
        return response()->json($response);
    }
}
