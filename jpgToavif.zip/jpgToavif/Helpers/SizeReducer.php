<?php

namespace App\Helpers;

/**
 * @example SizeReducer::GifToWebp('s.gif','r.webp');
 * @example SizeReducer::ImageToWebP('myket.png','ar.webp',0);
 * @example $files = scandir('./images');
 * $files = array_diff($files,['.','..']);
 * foreach ($files as $key => $value) {
 *   $path      = './images/'.$value;
 *   $new_path  = './newImages/'.$value.'.jpg';
 *   SizeReducer::ToWebP($path,$new_path,0);
 * }
 */
class SizeReducer
{
    public static function toWebp($path, $save_to, $new_width = 0)
    {
        $new_height = $new_width;
        $mime = getimagesize($path); //get mime type of image

        if ($mime['mime'] == 'image/png') {
            $src_img = imagecreatefrompng($path); //Create a new image from file or URL
        }
        if ($mime['mime'] == 'image/jpg' || $mime['mime'] == 'image/jpeg' || $mime['mime'] == 'image/pjpeg') {
            $src_img = imagecreatefromjpeg($path);
        }
        if ($mime['mime'] == 'image/webp') {
            $src_img = imagecreatefromwebp($path);
        }
        $old_x = imageSX($src_img); // Original picture width
        $old_y = imageSY($src_img); // Original picture height

        if ($new_width == 0) {
            $new_width = $old_x > $old_y ? $old_x : $old_y; // Maximum value
        }
        $new_height = $new_width; // Maximum value

        if ($old_x > $old_y) { // Horizontal picture
            $thumb_w = $new_width; // Width of thumbnail
            $thumb_h = $old_y * ($new_height / $old_x); // Height of thumbnail
        }

        if ($old_x < $old_y) { // Vertical picture
            $thumb_w = $old_x * ($new_width / $old_y); // Width of thumbnail
            $thumb_h = $new_height; // Height of thumbnail
        }

        if ($old_x == $old_y) { // Square picture
            $thumb_w = $new_width;
            $thumb_h = $new_height;
        }

        $dst_img = ImageCreateTrueColor($thumb_w, $thumb_h); // Create a new true color image

        imagecopyresampled($dst_img, $src_img, 0, 0, 0, 0, $thumb_w, $thumb_h, $old_x, $old_y); // Resample

        $result = imagewebp($dst_img, $save_to); // Save thumbnail

        imagedestroy($dst_img); // kill the file handles
        imagedestroy($src_img); // kill images from memory

        return $result; // return thumbnail
    }

    public static function toAvif($src, $output)
    {
        exec('convert "' . $src . '" "' . $output . '"'); // convert to avif
        return $output;
    }


    public static function optimize($path, $save_to): bool
    {

        $mime = getimagesize($path); //get mime type of image

        if ($mime['mime'] == 'image/png') {
            $src_img = imagecreatefrompng($path); //Create a new image from file or URL
        }
        if ($mime['mime'] == 'image/jpg' || $mime['mime'] == 'image/jpeg' || $mime['mime'] == 'image/pjpeg') {
            $src_img = imagecreatefromjpeg($path);
        }
        if ($mime['mime'] == 'image/webp') {
            $src_img = imagecreatefromwebp($path);
        }
        $old_x = imageSX($src_img); // Original picture width
        $old_y = imageSY($src_img); // Original picture height

        $new_width = $old_x > $old_y ? $old_x : $old_y; // Maximum value

        $new_height = $new_width; // Maximum value

        if ($old_x > $old_y) { // Horizontal picture
            $thumb_w = $new_width; // Width of thumbnail
            $thumb_h = $old_y * ($new_height / $old_x); // Height of thumbnail
        }

        if ($old_x < $old_y) { // Vertical picture
            $thumb_w = $old_x * ($new_width / $old_y); // Width of thumbnail
            $thumb_h = $new_height; // Height of thumbnail
        }

        if ($old_x == $old_y) { // Square picture
            $thumb_w = $new_width;
            $thumb_h = $new_height;
        }

        $dst_img = ImageCreateTrueColor($thumb_w, $thumb_h); // Create a new true color image

        imagecopyresampled($dst_img, $src_img, 0, 0, 0, 0, $thumb_w, $thumb_h, $old_x, $old_y); // Resample
        $result = imagejpeg($dst_img, $save_to,70);
        imagedestroy($dst_img); // kill the file handles
        imagedestroy($src_img); // kill images from memory
        return $result; // return thumbnail
    }
}
