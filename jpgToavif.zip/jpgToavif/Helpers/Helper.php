<?php

namespace App\Helpers;

use Image;
class Helper
{
    const FORMATS = ['jpg', 'avif', 'webp'];
    const SIZES = [200, 400, 600];

    public static function parse($path)
    {
        $path_info = pathInfo($path);
        $file_name = $path_info['filename'];

        // w
        $ex = explode('_w', $path_info['filename']);
        $w = false;
        if (count($ex) > 1) {
            $w = (int)str_replace('w', '', last($ex));
            $file_name = str_replace('_w' . $w, '', $file_name);
        }
        // end w

        return [
            'path' => '/' . $path_info['dirname'] . '/',
            'name' => $file_name,
            'ext' => $path_info['extension'],
            'w' => $w,
        ];
    }

    public static function exist($info)
    {
        $path = self::getPath($info, true);
        return file_exists($path);
    }

    public static function getPath($info, $public_path = false)
    {
        $path = $info['path'] . $info['name'] . ($info['w'] ? '_w' . $info['w'] : '') . '.' . $info['ext'];
        return $public_path
            ? public_path($path)
            : $path;
    }

    public static function response($info)
    {
        $path = self::getPath($info, true);
        switch ($info['ext']) {
            case 'avif':
                header("Content-Type: image/avif");
                return response()->file($path);
            default:
                return response()->file($path);
        }
    }

    public static function toWebp($info)
    {
        SizeReducer::toWebp(self::getPath([...$info, 'ext' => 'jpg'], true), self::getPath($info, true));
    }

    public static function toAvif($info)
    {
        SizeReducer::toAvif(self::getPath([...$info, 'ext' => 'jpg'], true), self::getPath($info, true));
    }

    public static function resizeJpg($info)
    {
        $img = Image::make(self::getPath([...$info, 'w' => false], true));
        $img->resize($info['w'], null, function ($constraint) {
            $constraint->aspectRatio();
        });
        $img->save(self::getPath($info, true));
    }
}
